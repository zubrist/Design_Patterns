package CompositeDesignPattern.FileSystem;

public interface FileSystem {
    public void ls();
    
}
