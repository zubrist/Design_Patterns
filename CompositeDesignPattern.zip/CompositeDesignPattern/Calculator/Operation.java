package CompositeDesignPattern.Calculator;

public enum Operation {
    ADD,
    SUBTRACT,
    MULTIPLY,
    DIVIDE;
    
}
