package CompositeDesignPattern.Calculator;

public interface ArithmeticExpression {
    public int calculate();
    
}
