package FactoryDesignPattern.PizzaStore2;

public class AmericanChickenPizza extends Pizza{
    
    public  AmericanChickenPizza(){
    name="American Chicken Pizza";
    style="American";
    type="Chicken";
    }
}
