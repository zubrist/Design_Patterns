package FactoryDesignPattern.PizzaStore2;

public class AmericanPizza extends Pizza  {

     public AmericanPizza(){
        name="American Pizza";
        style= "American";
     }
    
}
