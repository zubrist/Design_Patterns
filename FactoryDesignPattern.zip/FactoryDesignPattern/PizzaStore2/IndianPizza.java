package FactoryDesignPattern.PizzaStore2;

public class IndianPizza extends Pizza{

    public IndianPizza(){
        name="Indian Pizza";
        style="Indian";
    }
    
}
