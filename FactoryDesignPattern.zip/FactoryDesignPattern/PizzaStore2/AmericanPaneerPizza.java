package FactoryDesignPattern.PizzaStore2;

public class AmericanPaneerPizza extends Pizza {
    public AmericanPaneerPizza(){
        name= "American Panneer  Pizza";
        style= "American";
        type= "Paneer";
    }
    
}
