public class PepperoniPizza  extends Pizza{
    public PepperoniPizza(){

        name= "Pepperoni Pizza";
        dough="Thin Crust";
        souce= "I cant pronounce it souce";
        toppings.add("Sliced Pepperoni");
        toppings.add("Sliced Onion");
        toppings.add("Some Fency Toppings...");
    }
    
}
