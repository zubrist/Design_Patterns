public class CheesePizza extends Pizza{

    public CheesePizza(){
        name= "Cheese Pizza";
        dough = "Regular";
        souce ="Red Souce";
        toppings.add("toppngs1");
        toppings.add("toppings2");
        toppings.add("topppings3");
    }
}