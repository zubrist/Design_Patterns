public class VegPizza extends Pizza {
    public VegPizza(){

        name="Veggie Pizza";
        dough="Crust";
        souce="Some Fency souce";
        toppings.add("Diced Onion");
        toppings.add("Sliced Mashrooms");
        toppings.add("Some More fency toppings..S");

    }
    
}
